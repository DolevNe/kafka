"use strict";
const { Plugin, PluginSettingTab, Setting, Notice } = require("obsidian");

const DEFAULTS = { salt: "", hash: "", idleMinutes: 0 };

function randomSalt() {
  const a = new Uint8Array(16);
  crypto.getRandomValues(a);
  return Array.from(a, (b) => b.toString(16).padStart(2, "0")).join("");
}

async function sha256(text) {
  const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(text));
  return Array.from(new Uint8Array(buf), (b) => b.toString(16).padStart(2, "0")).join("");
}

module.exports = class PinLockPlugin extends Plugin {
  async onload() {
    this.settings = Object.assign({}, DEFAULTS, await this.loadData());
    this.overlay = null;
    this.idleTimer = null;

    // Lock immediately on startup
    this.lock();

    this.addCommand({ id: "lock-now", name: "Lock now", callback: () => this.lock() });
    this.addRibbonIcon("lock", "Lock now", () => this.lock());
    this.addSettingTab(new PinLockSettingTab(this.app, this));

    // Idle auto-lock
    const reset = () => this.resetIdle();
    ["mousemove", "keydown", "mousedown", "touchstart", "wheel"].forEach((ev) =>
      this.registerDomEvent(window, ev, reset, { passive: true })
    );
  }

  onunload() {
    this.unlock();
    if (this.idleTimer) clearTimeout(this.idleTimer);
  }

  resetIdle() {
    if (this.idleTimer) clearTimeout(this.idleTimer);
    const m = Number(this.settings.idleMinutes) || 0;
    if (m > 0 && !this.overlay) {
      this.idleTimer = setTimeout(() => this.lock(), m * 60 * 1000);
    }
  }

  async checkCode(code) {
    return (await sha256(this.settings.salt + code)) === this.settings.hash;
  }

  async setCode(code) {
    this.settings.salt = randomSalt();
    this.settings.hash = await sha256(this.settings.salt + code);
    await this.saveData(this.settings);
  }

  lock() {
    if (this.overlay) return;
    const isSetup = !this.settings.hash;

    const overlay = document.createElement("div");
    overlay.className = "pin-lock-overlay";
    const box = overlay.createDiv({ cls: "pin-lock-box" });
    const title = box.createEl("div", {
      cls: "pin-lock-title",
      text: isSetup ? "Set a code" : "Enter code",
    });
    const input = box.createEl("input", {
      cls: "pin-lock-input",
      attr: { type: "password", inputmode: "numeric", autocomplete: "off" },
    });
    let confirm = null;
    if (isSetup) {
      confirm = box.createEl("input", {
        cls: "pin-lock-input",
        attr: { type: "password", inputmode: "numeric", autocomplete: "off", placeholder: "Repeat code" },
      });
    }
    const msg = box.createEl("div", { cls: "pin-lock-msg" });
    const btn = box.createEl("button", { text: isSetup ? "Save" : "Unlock" });

    let busy = false;
    const submit = async () => {
      if (busy) return;
      busy = true;
      try {
        const code = input.value;
        if (isSetup) {
          if (code.length < 4) { msg.setText("At least 4 characters"); return; }
          if (code !== confirm.value) { msg.setText("Codes do not match"); return; }
          await this.setCode(code);
          new Notice("PIN Lock: code saved");
          this.unlock();
        } else if (await this.checkCode(code)) {
          this.unlock();
        } else {
          msg.setText("Wrong code");
          input.value = "";
          await new Promise((r) => setTimeout(r, 800)); // slow down guessing
          input.focus();
        }
      } finally {
        busy = false;
      }
    };

    btn.addEventListener("click", submit);

    // Block all keyboard input to Obsidian except our own fields
    this.keyBlocker = (e) => {
      const ours = e.target === input || e.target === confirm;
      if (!ours) { e.stopImmediatePropagation(); e.preventDefault(); input.focus(); return; }
      e.stopImmediatePropagation(); // ours: don't let Obsidian hotkeys see it
      if (e.key === "Enter" && e.type === "keydown") {
        if (isSetup && e.target === input) confirm.focus();
        else submit();
      }
    };
    window.addEventListener("keydown", this.keyBlocker, true);
    window.addEventListener("keyup", this.keyBlocker, true);

    // Keep focus on the lock screen
    this.focusKeeper = () => {
      if (!this.overlay) return;
      const a = document.activeElement;
      if (a !== input && a !== confirm) input.focus();
    };
    this.focusInterval = setInterval(this.focusKeeper, 300);

    document.body.appendChild(overlay);
    this.overlay = overlay;
    if (this.idleTimer) clearTimeout(this.idleTimer);
    setTimeout(() => input.focus(), 50);
  }

  unlock() {
    if (this.overlay) { this.overlay.remove(); this.overlay = null; }
    if (this.keyBlocker) {
      window.removeEventListener("keydown", this.keyBlocker, true);
      window.removeEventListener("keyup", this.keyBlocker, true);
      this.keyBlocker = null;
    }
    if (this.focusInterval) { clearInterval(this.focusInterval); this.focusInterval = null; }
    this.resetIdle();
  }
};

class PinLockSettingTab extends PluginSettingTab {
  constructor(app, plugin) { super(app, plugin); this.plugin = plugin; }

  display() {
    const { containerEl } = this;
    containerEl.empty();
    let cur = "", next = "";

    new Setting(containerEl)
      .setName("Auto-lock after idle (minutes)")
      .setDesc("0 = only on startup and manual lock")
      .addText((t) =>
        t.setValue(String(this.plugin.settings.idleMinutes)).onChange(async (v) => {
          this.plugin.settings.idleMinutes = Math.max(0, parseInt(v, 10) || 0);
          await this.plugin.saveData(this.plugin.settings);
          this.plugin.resetIdle();
        })
      );

    new Setting(containerEl).setName("Change code").setHeading();
    new Setting(containerEl).setName("Current code").addText((t) => {
      t.inputEl.type = "password";
      t.onChange((v) => (cur = v));
    });
    new Setting(containerEl).setName("New code").addText((t) => {
      t.inputEl.type = "password";
      t.onChange((v) => (next = v));
    });
    new Setting(containerEl).addButton((b) =>
      b.setButtonText("Change").setCta().onClick(async () => {
        if (!(await this.plugin.checkCode(cur))) { new Notice("Current code is wrong"); return; }
        if (next.length < 4) { new Notice("New code: at least 4 characters"); return; }
        await this.plugin.setCode(next);
        new Notice("Code changed");
        this.display();
      })
    );
  }
}
