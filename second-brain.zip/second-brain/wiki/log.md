---
title: Log
type: log
---

# Log

Append-only. Format: `## [YYYY-MM-DD] <ingest|query|lint> | <title>`

## [2026-10-19] init | Vault created
