Run the **Query** operation from CLAUDE.md for this question:

$ARGUMENTS

Start from `wiki/index.md`. Cite wiki pages with wikilinks. If the answer is reusable, save it to `outputs/` and file it into `wiki/synthesis/`.
