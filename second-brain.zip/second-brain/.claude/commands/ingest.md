Run the **Ingest** operation from CLAUDE.md.

Process every unprocessed file in `raw/` (skip `raw/processed/` and `raw/assets/`).
If $ARGUMENTS is given, process only that file.

Follow all 7 ingest steps. At the end, print a short table: source → pages created / pages updated.
