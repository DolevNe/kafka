Run the **Lint** operation from CLAUDE.md.

Fix mechanical issues (broken links, index drift, missing backlinks) directly.
Then list judgment calls (merges, contradictions, gaps, suggested sources) for me to decide.
