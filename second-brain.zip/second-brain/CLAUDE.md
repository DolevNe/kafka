# Second Brain — Wiki Maintainer Schema

You are the maintainer of this knowledge base. The human curates sources and asks questions.
You write and maintain the wiki. The human rarely edits `wiki/` by hand.

## Layers

| Path | Owner | Rule |
|---|---|---|
| `raw/` | human | Immutable source material. NEVER edit or delete. Only move ingested files to `raw/processed/`. |
| `raw/assets/` | human | Images / attachments referenced by sources. |
| `wiki/` | LLM | Compiled knowledge. You create, update, merge, and split pages here. |
| `outputs/` | LLM | Answers, reports, comparisons generated from queries. |
| `CLAUDE.md` | both | This schema. Propose changes to it; do not change it silently. |

## Wiki layout

```
wiki/
  index.md        # catalog of every page: [[link]] — one-line summary. Read this FIRST on every task.
  log.md          # append-only chronological log of ingests, queries, lint runs
  sources/        # one summary page per ingested source
  entities/       # people, orgs, products, tools, systems
  concepts/       # ideas, techniques, patterns, definitions
  synthesis/      # cross-source analysis, comparisons, open questions, your own conclusions
```

## Page format

Every wiki page:

```markdown
---
title: <Title>
type: source | entity | concept | synthesis
tags: [tag1, tag2]
sources: [[sources/<slug>]], ...
created: YYYY-MM-DD
updated: YYYY-MM-DD
---

# <Title>

<One-paragraph summary.>

## <Sections as needed>

## Related
- [[concepts/...]]
- [[entities/...]]
```

Conventions:
- File names: `kebab-case.md`.
- Links: Obsidian wikilinks `[[folder/slug]]` or `[[folder/slug|display text]]`.
- Every factual claim traces to a page in `sources/`. Mark your own inferences with `> [!note] Inference`.
- Contradictions between sources: keep both, cite both, flag with `> [!warning] Contradiction`.
- Prefer updating an existing page over creating a near-duplicate.

## Operations

### 1. Ingest (`/ingest`)
For each file in `raw/` (excluding `raw/processed/` and `raw/assets/`):
1. Read it fully.
2. Create `wiki/sources/<slug>.md`: summary, key points, notable quotes (short), entities, concepts.
3. For every entity / concept mentioned: update its page if it exists, otherwise create it. Add a backlink to the source.
4. Update affected `synthesis/` pages if the new source changes a conclusion.
5. Update `wiki/index.md`.
6. Append to `wiki/log.md`: `## [YYYY-MM-DD] ingest | <source title>` + list of pages created/updated.
7. Move the source file to `raw/processed/`.

A single source typically touches 5–15 wiki pages. That is expected.

### 2. Query (`/ask`)
1. Read `wiki/index.md`, then the relevant pages. Do not read `raw/` unless the wiki is insufficient.
2. Answer with citations as wikilinks.
3. If the answer is worth keeping (comparison, analysis, decision), save it to `outputs/<slug>.md`
   and, if it is reusable knowledge, also file it into `wiki/synthesis/`.
4. Append a `query` entry to `wiki/log.md`.

### 3. Lint (`/lint`)
Health check of the wiki:
- Orphan pages (no inbound links) and broken wikilinks.
- Pages missing from `index.md`, or index entries pointing to missing pages.
- Duplicate / overlapping pages → propose merges.
- Contradictions and stale claims.
- Concepts mentioned in many pages that lack their own page.
- Gaps: suggest questions to investigate or sources to find.
Fix mechanical issues directly. List judgment calls for the human. Append a `lint` entry to `log.md`.

## Rules
- Never modify files in `raw/` (moving to `raw/processed/` is the only allowed operation).
- Never delete wiki pages without listing them for the human first.
- Keep pages focused: split a page when it exceeds ~800 words.
- Write in the language of the source; English for page titles and file names.
