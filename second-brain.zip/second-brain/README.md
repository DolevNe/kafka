# Second Brain (Karpathy LLM Wiki pattern)

```
raw/        you drop sources here (immutable)
wiki/       LLM-compiled knowledge (Obsidian renders it)
outputs/    answers and reports from queries
CLAUDE.md   schema — the rules the LLM follows
```

## Setup

```bash
cd ~/second-brain
git init && git add -A && git commit -m "init"
```

1. Obsidian → Open folder as vault → `~/second-brain`
2. Settings → Files and links → Default location for new attachments → `raw/assets`
3. Install the Obsidian Web Clipper extension → set note location to `raw`

## Daily loop

```bash
cd ~/second-brain && claude
```

```
/ingest                 # compile everything new in raw/
/ask <question>         # query the wiki
/lint                   # weekly health check
```

Commit after each session:

```bash
git add -A && git commit -m "ingest $(date +%F)"
```
